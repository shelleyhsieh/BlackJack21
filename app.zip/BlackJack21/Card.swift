//
//  Card.swift
//  BlackJack21
//
//  Created by shelley on 2022/11/3.
//

import Foundation

class Card {
    var suit = ""
    var rank = ""
}

let suits = ["♠️", "♣️", "♥️", "♦️"]
let ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
